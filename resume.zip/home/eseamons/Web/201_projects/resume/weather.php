<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Eric Seamons' Resume</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
    <body>
        <h1 id="page_title">Weather Page for <?php echo $_GET['city']; ?> </h1>
        
        <div id="resume_block">
            <img src="http://images.clipartpanda.com/weather-clip-art-inclement_weather_Vector_Clipart.png">
        </div>
        
    </body>
</html>